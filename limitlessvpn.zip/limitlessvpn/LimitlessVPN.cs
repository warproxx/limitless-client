﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenVpnManagement;

namespace LimitlessVPN
{
    public partial class LimitlessVPN : Form
    {
        public LimitlessVPN()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Select OpenVPN Config";
            //fdlg.InitialDirectory = @"c:\";
            fdlg.Filter = "OpenVPN Config files |*.ovpn";
            fdlg.FilterIndex = 2;
            fdlg.RestoreDirectory = true;

            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                configBox.Text = fdlg.FileName;
            }

        }

       
        private void button1_Click(object sender, EventArgs e)
        {
            String location = configBox.Text;

            using (var mng = new Manager("127.0.0.1", 8888, location, username.Text, password.Text))
            {
                MessageBox.Show("Here");

                var a1 = mng.GetStatus();
                logBox.Text += a1;
                logBox.Text += "\r\n";

                var a2 = mng.GetPid();
                logBox.Text += a2;
                logBox.Text += "\r\n";

                var a3 = mng.GetHelp();
                logBox.Text += a3;
                logBox.Text += "\r\n";
            }

            MessageBox.Show("Out");

        }
    }
}
