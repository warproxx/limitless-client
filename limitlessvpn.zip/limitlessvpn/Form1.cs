﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LimitlessVPN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loginForm lf = new loginForm();
            this.Hide();
            lf.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            registerForm rf = new registerForm();
            this.Hide();
            rf.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LimitlessVPN lv = new LimitlessVPN();
            lv.ShowDialog();
        }
    }
}
