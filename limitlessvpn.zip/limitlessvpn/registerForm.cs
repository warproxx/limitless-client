﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LimitlessVPN
{
    public partial class registerForm : Form
    {
        public registerForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string URI = "https://limitlessvpn.com/auth/register.php";
            NameValueCollection data = new NameValueCollection();
            data["regEmail"] = regEmail.Text;
            data["regPass1"] = regPassword.Text;
            data["regPass2"] = regConfPassword.Text;

            try
            {


                using (WebClient wc = new WebClient())
                {
                    wc.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                    byte[] HtmlResult = wc.UploadValues(URI, "POST", data);
                    string htmlstringres = Encoding.UTF8.GetString(HtmlResult); //get the result from server
                    MessageBox.Show(htmlstringres);
                }
            }
            catch (Exception ef)
            {
                MessageBox.Show("Unexpected error!");
            }
        }
    }
}
