<?php
	$pdo = new PDO('mysql:dbname=limitlessvpn;host=127.0.0.1', 'root', 'toor');

	if(isset($_POST['regEmail']) && isset($_POST['regPass1']) && isset($_POST['regPass2'])){
		if($_POST['regPass1'] !== $_POST['regPass2']){
			echo 'The passwords do not match';
		}
		else{
			$check = $pdo->prepare("SELECT * FROM users WHERE user_name = :email");
			$check->execute(['email' => $_POST['regEmail']]);

			if($check->rowcount() > 0){
				echo 'The email is already registered.';
			}
			else{
				$reg = $pdo->prepare("INSERT INTO users(user_name, user_password) VALUES (:username, :password) ");
				$password = PASSWORD_HASH($_POST['regPass2'], PASSWORD_DEFAULT);

				$criteria = [
					'username' => $_POST['regEmail'],
					'password' => $password
				];

				$reg->execute($criteria);
				echo 'Successfully registered';
			}
		}
	}
	else{
		echo 'Don\'t leave any fields empty';
	}

?>