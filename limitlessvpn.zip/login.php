<?php
	$pdo = new PDO('mysql:dbname=limitlessvpn;host=127.0.0.1', 'root', 'toor');

	if(isset($_POST['loginEmail']) && isset($_POST['loginPassword'])){
		$quer = $pdo->prepare("SELECT user_password FROM users WHERE user_name = :username");
		$criteria = [
			'username' => $_POST['loginEmail']
		];
		$quer->execute($criteria);

		if($quer->rowcount() > 0){
			// echo 'Logged in';
			$pass = $quer->fetch();
			$password_ver = PASSWORD_VERIFY($_POST['loginPassword'], $pass['user_password']);

			if($password_ver){
				echo 'Logged in';
			}
			else{
				echo 'Username or password not matched';
			}
		}
		else{
			echo 'Username or password not matched';
		}
	}
	// echo password_hash('Angel132', PASSWORD_DEFAULT);
?>

